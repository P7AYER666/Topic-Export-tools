export const titleTemplate = {
  nodeType: "element",
  nodeName: "title",
  componentType: "LTitle",
  innerText: "Title Inner Text",
  width: "",
  height: "",
  childrenNodes: [{}],
};
