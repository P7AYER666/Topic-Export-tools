export const videoTemplate = {
  nodeType: "element",
  nodeName: "video",
  componentType: "LVideo",
  innerText: "Video Inner Text",
  width: "355",
  height: "188",
  childrenNodes: [{}],
};
