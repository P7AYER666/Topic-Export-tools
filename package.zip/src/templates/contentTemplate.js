export const contentTemplate = {
  nodeType: "element",
  nodeName: "content",
  componentType: "LContent",
  innerText: "Content Inner Text",
  width: "",
  height: "",
  childrenNodes: [{}],
};
